# indisidephy: inter- and intraspecific size variability of phytoplankton

insidephy is a package for modelling inter- and intraspecific 
size variability of phytoplankton grown under laboratory conditions.
