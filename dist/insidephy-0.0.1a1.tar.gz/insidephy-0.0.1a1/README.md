# InSiDePhy: Inter- and intraspecific Size Diversity of Phytoplankton

_insidephy_ is a package for modelling inter- and intraspecific 
size variability of phytoplankton grown under laboratory conditions.



