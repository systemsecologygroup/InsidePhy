import numpy as np
import pandas as pd
import time
import insidephy.size_based_models.allometric_functions as allo
import matplotlib.pyplot as plt


class PhytoCell:
    """
    Phytoplankton cell (agent) is characterised by its nutrient related traits,
    which are determined by allometric functions observed by
    Marañon et al. (2013, Eco. Lett.)
    :param min_cell_size: minimum cell size of phytoplankton population (um^3)
    :param max_cell_size: maximum cell size of phytoplankton population (um^3)
    :param init_cell_size: initial cell size (um^3 / cell)
    :param init_biomass: initial biomass of cell (mol C / cell)
    :param init_quota: initial quota (umol N / mol C)
    """

    def __init__(self, min_cell_size=0.12, max_cell_size=2.5e7, rep_nind=None,
                 init_cell_size=None, init_biomass=None, init_quota=None):
        # traits and variables:
        if init_cell_size is None:
            self.cell_size = 10 ** np.random.uniform(np.log10(min_cell_size),
                                                     np.log10(max_cell_size))  # Volume um3/cell
        else:
            self.cell_size = init_cell_size
        if init_biomass is None:
            self.ini_biomass = allo.biomass(self.cell_size)  # C biomass pgC/cell -> molC/cell
        else:
            self.ini_biomass = init_biomass  # molC/cell
        self.q_max = allo.q_max(
            self.cell_size) / self.ini_biomass  # Max Quota pgN/cell -> molN/molC
        self.q_min = allo.q_min(
            self.cell_size) / self.ini_biomass  # Min Quota pgN/cell -> molN/molC
        self.v_max = allo.v_max(
            self.cell_size) / self.ini_biomass  # Max uptake velocity pgN/cell*day -> molN/molC*day
        self.mu_max = allo.mu_max(self.cell_size)  # Maximum growth rate 1/day
        self.kr = allo.k_r(self.cell_size)  # resource half-saturation molN/L = MN
        if init_quota is None:
            self.quota = (self.q_min + self.q_max) / 2.  # Cell Quota (molN/molC)
        else:
            self.quota = init_quota  # Cell Quota (molN/molC)
        self.biomass = self.ini_biomass  # Cell biomass (molC/cell)
        self.V = 0.0
        self.mu = 0.0
        if rep_nind is None:
            self.rep_nind = 1e0
        else:
            self.rep_nind = rep_nind
        self.massbalance = None

    def growth(self, r, tstep):
        self.V = self.v_max * ((self.q_max - self.quota) / (self.q_max - self.q_min)) * (r / (self.kr + r))
        #      = molN/molC*day * ([molN/molC - molN/molC]/[molN/molC - molN/molC]) * (MN/[MN + MN])
        #      = molN/molC*day
        self.massbalance = self.V * self.biomass * self.rep_nind
        self.mu = self.mu_max * (1. - (self.q_min / self.quota))  # 0.
        #       = 1/day * (1. - molN/molC / molN/molC)
        #       = 1/day
        self.quota += (self.V - self.mu * self.quota) * tstep
        #           = (molN/molC*day - 1/day * molN/molC) * day
        #           = molN/molC
        self.biomass += (self.mu * self.biomass) * tstep
        #             = (1/day * molC/cell) * day
        #             = molC/cell
        self.cell_size = allo.biomass_to_size(self.biomass)


class SBMi:
    """
    Size-based model of individual phytoplankton cells.
    """

    def __init__(self, ini_resource, ini_density, spp_names, min_size, max_size,
                 nsi_spp, nsi_min, nsi_max, dilution_rate,
                 volume, time_end=20, time_step=1 / 24, print_time_step=1,
                 timeit=False, random_seed=12345):
        """

        :param ini_resource:
        :param ini_density:
        :param spp_names:
        :param min_size:
        :param max_size:
        :param nsi_spp:
        :param nsi_min:
        :param nsi_max:
        :param dilution_rate:
        :param volume:
        :param time_end:
        :param time_step:
        :param print_time_step:
        :param timeit:
        """
        if not all([isinstance(item, list) or isinstance(item, tuple)
                    for item in iter([spp_names, ini_density, min_size, max_size, nsi_spp])]):
            raise TypeError('Error on input parameters spp_names, ini_density, min_size, max_size or nsi_spp. '
                            'Input parameters must be type list or tuple.')
        if not all([len(lst) == len(spp_names) for lst in iter([spp_names, ini_density, min_size, max_size, nsi_spp])]):
            raise ValueError("initial values of spp_names, ini_density, min_size, max_size and nsi_spp "
                             "must be lists of the same length depending on the number of species use "
                             "in the simulation")

        self.timeit = timeit
        self.R0 = ini_resource  # initial concentration of resource
        self.R = ini_resource  # concentration of resource

        self.spp_names = spp_names
        self.nind = ini_density  # initial number of individuals
        self.minsize = min_size  # Minimum cell size in um^3
        self.maxsize = max_size  # Maximum cell size in um^3
        self.nsi_min = nsi_min  # Minimum number of super individuals per species
        self.nsi_max = nsi_max  # Maximum number of super individuals per species
        self.nsi_ave = (nsi_min + nsi_max) // 2  # Average number of super individuals
        self.nsi_spp = list(nsi_spp)  # Number of super individuals per species
        self.dt = time_step  # time step of simulation fraction of day
        self.dtp = print_time_step  # time step to print
        self.time = np.linspace(0, time_end, int((time_end + self.dtp) / self.dtp))
        self.dilution_rate = dilution_rate  # dilution rate
        self.volume = volume  # volume
        self.pdic = {}  # dictionary of phytoplankton agents
        self.ddic = {}  # dictionary of dead phytoplankton agents
        # initialize output arrays
        self.resource = np.zeros(len(self.time))
        self.abundance = np.zeros(len(self.time))
        self.biomass = np.zeros(len(self.time))
        self.quota = np.zeros(len(self.time))
        self.massbalance = np.zeros(len(self.time))
        self.number_si = np.zeros((len(self.spp_names), len(self.time)))
        self.agents_size = np.zeros((len(self.spp_names), len(self.time), nsi_max))
        self.agents_biomass = np.zeros((len(self.spp_names), len(self.time), nsi_max))
        self.agents_abundance = np.zeros((len(self.spp_names), len(self.time), nsi_max))
        self.agents_growth = np.zeros((len(self.spp_names), len(self.time), nsi_max))
        self.agents_quota = np.zeros((len(self.spp_names), len(self.time), nsi_max))
        self.agents_size[:] = np.nan
        self.agents_biomass[:] = np.nan
        self.agents_abundance[:] = np.nan
        self.agents_growth[:] = np.nan
        # np.random.seed(1234)
        # self.initialize()
        # self.run()
        self.spp_si = {}
        self._rng = np.random.default_rng(random_seed)
        self.spp_names = ("Aa", "Bb")
        self.dtf = pd.DataFrame({
            'time': None,
            'resource': None,
            'spp': np.array([]),
            'id': np.array([]),
            'cell_size': np.array([]),
            'q_max': np.array([]),
            'q_min': np.array([]),
            'v_max': np.array([]),
            'mu_max': np.array([]),
            'kr': np.array([]),
            'ini_biomass': np.array([]),
            'biomass': np.array([]),
            'quota': np.array([]),
            'rep_nind': np.array([])
        })

    def initialize(self, number_agents=(10, 10),
                   min_cell_size=(1.5e1, 1.5e4), max_cell_size=(2.5e1, 2.5e4),
                   number_individuals=(1e4, 1e4), resource=2e-4):

        spp_size_spectra = np.array([10 ** self._rng.uniform(np.log10(minsize), np.log10(maxsize), size=ag)
                                     for minsize, maxsize, ag in
                                     zip(min_cell_size, max_cell_size, number_agents)]).flatten()
        spp_super_individuals = {
            'time': 0,
            'resource': resource,
            'spp': np.repeat(self.spp_names, number_agents),
            'id': np.array([np.arange(ag) for ag in number_agents]).flatten(),
            'cell_size': spp_size_spectra,
            'q_max': allo.q_max(spp_size_spectra),
            'q_min': allo.q_min(spp_size_spectra),
            'v_max': allo.v_max(spp_size_spectra),
            'mu_max': allo.mu_max(spp_size_spectra),
            'kr': allo.k_r(spp_size_spectra),
            'ini_biomass': allo.biomass(spp_size_spectra),
            'biomass': allo.biomass(spp_size_spectra),
            'quota': (allo.q_max(spp_size_spectra) + allo.q_min(spp_size_spectra)) / 2,
            'rep_nind': np.repeat(np.array(number_individuals) / np.array(number_agents), number_agents)
        }

        self.spp_si.update(spp_super_individuals)
        self.dtf = self.dtf.append(pd.DataFrame(self.spp_si))

    def update(self):
        spp_si = self.spp_si.copy()
        spp_si['V'] = spp_si['v_max'] * ((spp_si['q_max'] - spp_si['quota']) /
                                         (spp_si['q_max'] - spp_si['q_min'])) * \
                      (spp_si['resource'] / (spp_si['kr'] + spp_si['resource']))
        #           = molN/molC*day * ([molN/molC - molN/molC]/[molN/molC - molN/molC]) * (MN/[MN + MN])
        #           = molN/molC*day
        spp_si['massbalance'] = spp_si['V'] * spp_si['biomass'] * spp_si['rep_nind'] * self.dt
        #                     = molN/molC*day * molC/cell * cell * day
        #                     = molN
        spp_si['mu'] = spp_si['mu_max'] * (1. - (spp_si['q_min'] / spp_si['quota']))  # 0.
        #            = 1/day * (1. - molN/molC / molN/molC)
        #            = 1/day
        spp_si['quota'] = spp_si['quota'] + (spp_si['V'] - spp_si['mu'] * spp_si['quota']) * self.dt
        #                = (molN/molC*day - 1/day * molN/molC) * day
        #                = molN/molC
        spp_si['biomass'] = spp_si['biomass'] + (spp_si['mu'] * spp_si['biomass']) * self.dt
        #                 = (1/day * molC/cell) * day
        #                 = molC/cell
        spp_si['cell_size'] = allo.biomass_to_size(spp_si['biomass'])
        #
        spp_si['resource'] = spp_si['resource'] + (self.dilution_rate * (self.R0 - spp_si['resource'])) * self.dt - \
                             spp_si['massbalance'].sum() / self.volume
        #                   = molN/L + molN/(day * L) * day + molN/L
        #                   = molN/L

        # Asexual Reproduction
        offspring = {}
        reproduce = spp_si['biomass'] > 2 * spp_si['ini_biomass']
        if any(reproduce):
            print("Births!!")
            halfbiomass = spp_si['biomass'][reproduce] * 0.5
            halfquota = spp_si['quota'][reproduce] * spp_si['biomass'][reproduce] * 0.5 / halfbiomass
            halfcellsize = spp_si['cell_size'][reproduce] * 0.5
            spp_si['biomass'][reproduce] = halfbiomass  # set biomass to half biomass
            spp_si['quota'][reproduce] = halfquota  # set quota to half quota
            spp_si['cell_size'][reproduce] = halfcellsize  # set cell size to half cell size
            new_spp_si = [spp_si['spp'][reproduce][spp_si['spp'][reproduce] == spp].size + spp_si['id'][
                spp_si['spp'] == spp].max() + 1 for spp in self.spp_names]
            num_spp_si = [spp_si['id'][spp_si['spp'] == spp].size for spp in self.spp_names]

            offspring['spp'] = np.repeat(self.spp_names, np.array(new_spp_si) - np.array(num_spp_si))
            offspring['id'] = np.concatenate([np.arange(old_ag, new_ag) for new_ag, old_ag in zip(new_spp_si, num_spp_si)])
            offspring['ini_biomass'] = halfbiomass
            offspring['biomass'] = halfbiomass
            offspring['quota'] = halfquota
            offspring['cell_size'] = halfcellsize
            offspring['q_max'] = allo.q_max(halfcellsize)
            offspring['q_min'] = allo.q_min(halfcellsize)
            offspring['v_max'] = allo.v_max(halfcellsize)
            offspring['mu_max'] = allo.mu_max(halfcellsize)
            offspring['kr'] = allo.k_r(halfcellsize)
            offspring['rep_nind'] = spp_si['rep_nind'][reproduce]

        # Dilution lost
        die = self._rng.random(size=spp_si['spp'].size) < self.dilution_rate * self.dt
        die_ma = die != True
        spp_si['spp'] = spp_si['spp'][die_ma]
        spp_si['id'] = spp_si['id'][die_ma]
        spp_si['ini_biomass'] = spp_si['ini_biomass'][die_ma]
        spp_si['biomass'] = spp_si['biomass'][die_ma]
        spp_si['quota'] = spp_si['quota'][die_ma]
        spp_si['cell_size'] = spp_si['cell_size'][die_ma]
        spp_si['q_max'] = spp_si['q_max'][die_ma]
        spp_si['q_min'] = spp_si['q_min'][die_ma]
        spp_si['v_max'] = spp_si['v_max'][die_ma]
        spp_si['mu_max'] = spp_si['mu_max'][die_ma]
        spp_si['kr'] = spp_si['kr'][die_ma]
        spp_si['rep_nind'] = spp_si['rep_nind'][die_ma]

        self.spp_si.update({k: np.append(spp_si[k], offspring[k]) for k in offspring.keys()})
        self.spp_si['time'] = spp_si['time'] + self.dtp
        self.spp_si['resource'] = spp_si['resource']
        self.dtf = self.dtf.append(pd.DataFrame(self.spp_si))

    def save_to_array(self, t_print):
        # Resource concentration
        # self.resource[t_print] = self.R
        abundance = []
        biomass = []
        quota = []

        for key in self.pdic.keys():
            abundance.append(self.pdic[key].rep_nind)
            biomass.append(self.pdic[key].biomass * self.pdic[key].rep_nind)
            quota.append(self.pdic[key].quota * self.pdic[key].biomass * self.pdic[key].rep_nind)

        quota_deadcell = [self.ddic[key].quota * self.ddic[key].biomass * self.ddic[key].rep_nind for key in
                          self.ddic.keys()]

        # Resource concentration
        self.resource[t_print] = self.R
        # Abundance
        self.abundance[t_print] = np.sum(abundance)
        # total biomass of phytoplankton agents
        self.biomass[t_print] = np.sum(biomass)
        # PON of phytoplankton agents
        self.quota[t_print] = np.sum(quota)
        # Mass Balance
        self.massbalance[t_print] = self.R + 1. / self.volume * np.sum(quota) + np.sum(quota_deadcell)
        # Number of super individuals
        self.number_si[:, t_print] = self.nsi_spp

        # Agents
        for i, spp in enumerate(self.spp_names):
            for k, key in enumerate(self.pdic.keys()):
                if spp in key:
                    # print(i, spp, k, key)
                    # Cell size
                    self.agents_size[i, t_print, k] = self.pdic[key].cell_size
                    # Biomass
                    self.agents_biomass[i, t_print, k] = self.pdic[key].biomass * self.pdic[key].rep_nind
                    # Abundance
                    self.agents_abundance[i, t_print, k] = self.pdic[key].rep_nind
                    # Growth rate
                    self.agents_growth[i, t_print, k] = self.pdic[key].mu
                    # Quota
                    self.agents_quota[i, t_print, k] = self.pdic[key].quota * self.pdic[key].biomass * \
                                                       self.pdic[key].rep_nind

    def split_combine(self, nsi_max=30, nsi_ave=15):
        """
        Algorithm to control the number of super-individuals during the simulation
        by splitting or combining them when their numbers increase or decrease
        predefined limits (Clark et al. 2011).
        """
        spp_si = self.spp_si.copy()

        num_spp_si = [spp_si['id'][spp_si['spp'] == spp].size for spp in self.spp_names]

        if any(np.array(num_spp_si) > nsi_max):
            spp_combined = np.array(self.spp_names)[np.array(num_spp_si) > nsi_max]
            max_biomass = sorted(spp_si['biomass'][spp_si['spp'] == spp_combined])[-((40-nsi_max)+nsi_ave):]

        # TODO: Vectorize split-combined algorithm


        while np.sum(self.nsi_spp) > self.nsi_max:
            pdic_copy = self.pdic.copy()  # copy of pdic
            sp_idx = self.nsi_spp.index(np.max(self.nsi_spp))  # get index of sp with max number of super individuals
            sp_name = self.spp_names[sp_idx]  # get name of sp with max number of super individuals
            while np.sum(self.nsi_spp) > self.nsi_ave and self.nsi_spp[sp_idx] > 1:
                # dictionary filtered by species with max number of super individuals
                spdic = {key: val for key, val in pdic_copy.items() if key.startswith(sp_name)}
                # sorted keys of dictionary based on biomass, where first element in list is the smallest cell
                keysort = [key for key, val in sorted(spdic.items(), key=lambda kv: kv[1].biomass)]
                bmcombined = (pdic_copy[keysort[0]].biomass * pdic_copy[keysort[0]].rep_nind +
                              pdic_copy[keysort[1]].biomass * pdic_copy[keysort[1]].rep_nind) \
                             / (pdic_copy[keysort[0]].rep_nind + pdic_copy[keysort[1]].rep_nind)
                cscombined = (pdic_copy[keysort[0]].cell_size * pdic_copy[keysort[0]].rep_nind +
                              pdic_copy[keysort[1]].cell_size * pdic_copy[keysort[1]].rep_nind) \
                             / (pdic_copy[keysort[0]].rep_nind + pdic_copy[keysort[1]].rep_nind)
                qcombined = (pdic_copy[keysort[0]].quota * pdic_copy[keysort[0]].biomass * pdic_copy[
                    keysort[0]].rep_nind +
                             pdic_copy[keysort[1]].quota * pdic_copy[keysort[1]].biomass * pdic_copy[
                                 keysort[1]].rep_nind) \
                            / (pdic_copy[keysort[0]].rep_nind + pdic_copy[keysort[1]].rep_nind)
                qcombined = qcombined / bmcombined
                rncombined = pdic_copy[keysort[0]].rep_nind + pdic_copy[keysort[1]].rep_nind
                combinedkey = sp_name + str(len(keysort) - 2).zfill(5)
                newspdic = {sp_name + str(nag).zfill(5): pdic_copy[key] for nag, key in
                            zip(range(len(keysort) - 2), keysort[2:])}
                newspdic.update({combinedkey: PhytoCell(init_biomass=bmcombined, init_quota=qcombined,
                                                        init_cell_size=cscombined, rep_nind=rncombined)})
                newspdic.update({key: val for key, val in pdic_copy.items() if not sp_name in key})
                pdic_copy = newspdic.copy()
                self.nsi_spp[sp_idx] -= 1
            self.pdic = pdic_copy
        while np.sum(self.nsi_spp) < self.nsi_min:
            # print('split')
            pdic_copy = self.pdic.copy()  # copy of pdic
            sp_idx = self.nsi_spp.index(min(self.nsi_spp))  # get index of sp with min number of super individuals
            sp_name = self.spp_names[sp_idx]  # get name of sp with min number of super individuals
            while np.sum(self.nsi_spp) < self.nsi_ave:
                # dictionary filtered by species with min number of super individuals
                spdic = {key: val for key, val in pdic_copy.items() if key.startswith(sp_name)}
                # sorted keys of dictionary based on biomass, where first element in list is the largest cell
                keysort = [key for key, val in sorted(spdic.items(), key=lambda kv: kv[1].biomass, reverse=True)]
                splitkey = sp_name + '_split'
                rnsplit = spdic[keysort[0]].rep_nind / 2
                spdic.update({splitkey: PhytoCell(init_biomass=spdic[keysort[0]].biomass,
                                                  init_cell_size=spdic[keysort[0]].cell_size,
                                                  init_quota=spdic[keysort[0]].quota * spdic[keysort[0]].biomass \
                                                             * spdic[keysort[0]].rep_nind,
                                                  rep_nind=rnsplit)})
                spdic[keysort[0]].rep_nind = rnsplit
                newspdic = {sp_name + str(nag).zfill(5): spdic[key] for nag, key in
                            zip(range(len(spdic)), spdic.keys())}
                newspdic.update({key: val for key, val in pdic_copy.items() if not sp_name in key})
                pdic_copy = newspdic.copy()
                self.nsi_spp[sp_idx] += 1
            self.pdic = pdic_copy

    def run(self):
        start_comp_time = time.time()
        simtime = self.dt  # Simulation time
        printtime = self.dtp  # Print time step
        indexpt = 1  # index of print time step to save results
        self.initialize()
        while simtime <= self.time.max() + self.dt:
            self.update()  # Update state of all agents
            if simtime >= printtime:  # Save results
                self.dtf = self.dtf.append(pd.DataFrame(self.spp_si))
                printtime += self.dtp
                indexpt += 1
            simtime += self.dt  # increase simulation time by one time step (fraction of a day)
        if self.timeit:
            print('SBMi total simulation time %.2f minutes' % ((time.time() - start_comp_time) / 60.))


def test_dev():
    mod = SBMi(ini_resource=0.0002, ini_density=(1e4, 1e4), min_size=(1.5e1, 1.5e4), max_size=(2.5e1, 2.5e4),
               spp_names=('Aa', 'Bb'), dilution_rate=0.0, volume=1.0, nsi_spp=(500, 500), nsi_min=200,
               nsi_max=2000)

    mod.run()
    plt.figure()
    plt.plot()
    return mod


